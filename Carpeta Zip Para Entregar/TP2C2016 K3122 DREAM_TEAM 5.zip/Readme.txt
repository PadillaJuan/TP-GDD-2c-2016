GRUPO 5 DREAM_TEAM CURSO K3122

Integrantes del grupo:
AMARILLO, Juan Alberto. 		Legajo N�: 152.508-6. Curso: K3021
BIONDI BONOMINI, Marco Fernando.	Legajo N�: 153.052-5. Curso: K3071 
D�TTOLI, Lucas Nahuel. 			Legajo N�: 152.771-0. Curso: K3022
PADILLA, Juan Ignacio.(Responsable)	Legajo N�: 153.064-1. Curso: K3122

EMAIL DEL RESPONSABLE
juanpadilla.jip@gmail.com