﻿namespace ClinicaFrba.Registrar_Agenta_Medico
{
    partial class Registrar_agenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lunes_activar = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.horainicio_min_lunes = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.horainicio_hora_lunes = new System.Windows.Forms.ComboBox();
            this.horafin_min_lunes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.horafin_hora_lunes = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.especialidad_lunes = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.martes_activar = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.horainicio_min_martes = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.horainicio_hora_martes = new System.Windows.Forms.ComboBox();
            this.horafin_min_martes = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.horafin_hora_martes = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.especialidad_martes = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.miercoles_activar = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.horainicio_min_miercoles = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.horainicio_hora_miercoles = new System.Windows.Forms.ComboBox();
            this.horafin_min_miercoles = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.horafin_hora_miercoles = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.especialidad_miercoles = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.jueves_activar = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.horainicio_min_jueves = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.horainicio_hora_jueves = new System.Windows.Forms.ComboBox();
            this.horafin_min_jueves = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.horafin_hora_jueves = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.especialidad_jueves = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.viernes_activar = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.horainicio_min_viernes = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.horainicio_hora_viernes = new System.Windows.Forms.ComboBox();
            this.horafin_min_viernes = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.horafin_hora_viernes = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.especialidad_viernes = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.sabado_activar = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.horainicio_min_sabado = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.horainicio_hora_sabado = new System.Windows.Forms.ComboBox();
            this.horafin_min_sabado = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.horafin_hora_sabado = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.especialidad_sabado = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.fecha_desde = new System.Windows.Forms.DateTimePicker();
            this.fecha_hasta = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lunes_activar);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.horainicio_min_lunes);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.horainicio_hora_lunes);
            this.groupBox1.Controls.Add(this.horafin_min_lunes);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.horafin_hora_lunes);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.especialidad_lunes);
            this.groupBox1.Location = new System.Drawing.Point(22, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 65);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lunes";
            // 
            // lunes_activar
            // 
            this.lunes_activar.AutoSize = true;
            this.lunes_activar.Location = new System.Drawing.Point(19, 41);
            this.lunes_activar.Name = "lunes_activar";
            this.lunes_activar.Size = new System.Drawing.Size(15, 14);
            this.lunes_activar.TabIndex = 9;
            this.lunes_activar.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Activar";
            // 
            // horainicio_min_lunes
            // 
            this.horainicio_min_lunes.FormattingEnabled = true;
            this.horainicio_min_lunes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_lunes.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_lunes.Name = "horainicio_min_lunes";
            this.horainicio_min_lunes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_lunes.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hora Inicio";
            // 
            // horainicio_hora_lunes
            // 
            this.horainicio_hora_lunes.FormattingEnabled = true;
            this.horainicio_hora_lunes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horainicio_hora_lunes.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_lunes.Name = "horainicio_hora_lunes";
            this.horainicio_hora_lunes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_lunes.TabIndex = 5;
            // 
            // horafin_min_lunes
            // 
            this.horafin_min_lunes.FormattingEnabled = true;
            this.horafin_min_lunes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_lunes.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_lunes.Name = "horafin_min_lunes";
            this.horafin_min_lunes.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_lunes.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hora Fin";
            // 
            // horafin_hora_lunes
            // 
            this.horafin_hora_lunes.FormattingEnabled = true;
            this.horafin_hora_lunes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horafin_hora_lunes.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_lunes.Name = "horafin_hora_lunes";
            this.horafin_hora_lunes.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_lunes.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(319, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Seleccionar Especialidad";
            // 
            // especialidad_lunes
            // 
            this.especialidad_lunes.FormattingEnabled = true;
            this.especialidad_lunes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.especialidad_lunes.Location = new System.Drawing.Point(324, 38);
            this.especialidad_lunes.Name = "especialidad_lunes";
            this.especialidad_lunes.Size = new System.Drawing.Size(223, 21);
            this.especialidad_lunes.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.martes_activar);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.horainicio_min_martes);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.horainicio_hora_martes);
            this.groupBox2.Controls.Add(this.horafin_min_martes);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.horafin_hora_martes);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.especialidad_martes);
            this.groupBox2.Location = new System.Drawing.Point(22, 156);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(553, 65);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Martes";
            // 
            // martes_activar
            // 
            this.martes_activar.AutoSize = true;
            this.martes_activar.Location = new System.Drawing.Point(19, 41);
            this.martes_activar.Name = "martes_activar";
            this.martes_activar.Size = new System.Drawing.Size(15, 14);
            this.martes_activar.TabIndex = 9;
            this.martes_activar.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Activar";
            // 
            // horainicio_min_martes
            // 
            this.horainicio_min_martes.FormattingEnabled = true;
            this.horainicio_min_martes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_martes.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_martes.Name = "horainicio_min_martes";
            this.horainicio_min_martes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_martes.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(68, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Hora Inicio";
            // 
            // horainicio_hora_martes
            // 
            this.horainicio_hora_martes.FormattingEnabled = true;
            this.horainicio_hora_martes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horainicio_hora_martes.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_martes.Name = "horainicio_hora_martes";
            this.horainicio_hora_martes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_martes.TabIndex = 5;
            // 
            // horafin_min_martes
            // 
            this.horafin_min_martes.FormattingEnabled = true;
            this.horafin_min_martes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_martes.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_martes.Name = "horafin_min_martes";
            this.horafin_min_martes.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_martes.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(190, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Hora Fin";
            // 
            // horafin_hora_martes
            // 
            this.horafin_hora_martes.FormattingEnabled = true;
            this.horafin_hora_martes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horafin_hora_martes.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_martes.Name = "horafin_hora_martes";
            this.horafin_hora_martes.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_martes.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(319, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Seleccionar Especialidad";
            // 
            // especialidad_martes
            // 
            this.especialidad_martes.FormattingEnabled = true;
            this.especialidad_martes.Location = new System.Drawing.Point(324, 38);
            this.especialidad_martes.Name = "especialidad_martes";
            this.especialidad_martes.Size = new System.Drawing.Size(223, 21);
            this.especialidad_martes.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.miercoles_activar);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.horainicio_min_miercoles);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.horainicio_hora_miercoles);
            this.groupBox3.Controls.Add(this.horafin_min_miercoles);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.horafin_hora_miercoles);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.especialidad_miercoles);
            this.groupBox3.Location = new System.Drawing.Point(22, 227);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(553, 65);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Miércoles";
            // 
            // miercoles_activar
            // 
            this.miercoles_activar.AutoSize = true;
            this.miercoles_activar.Location = new System.Drawing.Point(19, 41);
            this.miercoles_activar.Name = "miercoles_activar";
            this.miercoles_activar.Size = new System.Drawing.Size(15, 14);
            this.miercoles_activar.TabIndex = 9;
            this.miercoles_activar.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Activar";
            // 
            // horainicio_min_miercoles
            // 
            this.horainicio_min_miercoles.FormattingEnabled = true;
            this.horainicio_min_miercoles.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_miercoles.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_miercoles.Name = "horainicio_min_miercoles";
            this.horainicio_min_miercoles.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_miercoles.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(68, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Hora Inicio";
            // 
            // horainicio_hora_miercoles
            // 
            this.horainicio_hora_miercoles.FormattingEnabled = true;
            this.horainicio_hora_miercoles.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horainicio_hora_miercoles.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_miercoles.Name = "horainicio_hora_miercoles";
            this.horainicio_hora_miercoles.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_miercoles.TabIndex = 5;
            // 
            // horafin_min_miercoles
            // 
            this.horafin_min_miercoles.FormattingEnabled = true;
            this.horafin_min_miercoles.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_miercoles.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_miercoles.Name = "horafin_min_miercoles";
            this.horafin_min_miercoles.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_miercoles.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(190, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Hora Fin";
            // 
            // horafin_hora_miercoles
            // 
            this.horafin_hora_miercoles.FormattingEnabled = true;
            this.horafin_hora_miercoles.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horafin_hora_miercoles.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_miercoles.Name = "horafin_hora_miercoles";
            this.horafin_hora_miercoles.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_miercoles.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(319, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Seleccionar Especialidad";
            // 
            // especialidad_miercoles
            // 
            this.especialidad_miercoles.FormattingEnabled = true;
            this.especialidad_miercoles.Location = new System.Drawing.Point(324, 38);
            this.especialidad_miercoles.Name = "especialidad_miercoles";
            this.especialidad_miercoles.Size = new System.Drawing.Size(223, 21);
            this.especialidad_miercoles.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.jueves_activar);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.horainicio_min_jueves);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.horainicio_hora_jueves);
            this.groupBox4.Controls.Add(this.horafin_min_jueves);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.horafin_hora_jueves);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.especialidad_jueves);
            this.groupBox4.Location = new System.Drawing.Point(22, 298);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(553, 65);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Jueves";
            // 
            // jueves_activar
            // 
            this.jueves_activar.AutoSize = true;
            this.jueves_activar.Location = new System.Drawing.Point(19, 41);
            this.jueves_activar.Name = "jueves_activar";
            this.jueves_activar.Size = new System.Drawing.Size(15, 14);
            this.jueves_activar.TabIndex = 9;
            this.jueves_activar.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Activar";
            // 
            // horainicio_min_jueves
            // 
            this.horainicio_min_jueves.FormattingEnabled = true;
            this.horainicio_min_jueves.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_jueves.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_jueves.Name = "horainicio_min_jueves";
            this.horainicio_min_jueves.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_jueves.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(68, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Hora Inicio";
            // 
            // horainicio_hora_jueves
            // 
            this.horainicio_hora_jueves.FormattingEnabled = true;
            this.horainicio_hora_jueves.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horainicio_hora_jueves.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_jueves.Name = "horainicio_hora_jueves";
            this.horainicio_hora_jueves.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_jueves.TabIndex = 5;
            // 
            // horafin_min_jueves
            // 
            this.horafin_min_jueves.FormattingEnabled = true;
            this.horafin_min_jueves.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_jueves.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_jueves.Name = "horafin_min_jueves";
            this.horafin_min_jueves.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_jueves.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(190, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Hora Fin";
            // 
            // horafin_hora_jueves
            // 
            this.horafin_hora_jueves.FormattingEnabled = true;
            this.horafin_hora_jueves.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horafin_hora_jueves.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_jueves.Name = "horafin_hora_jueves";
            this.horafin_hora_jueves.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_jueves.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(319, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Seleccionar Especialidad";
            // 
            // especialidad_jueves
            // 
            this.especialidad_jueves.FormattingEnabled = true;
            this.especialidad_jueves.Location = new System.Drawing.Point(324, 38);
            this.especialidad_jueves.Name = "especialidad_jueves";
            this.especialidad_jueves.Size = new System.Drawing.Size(223, 21);
            this.especialidad_jueves.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.viernes_activar);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.horainicio_min_viernes);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.horainicio_hora_viernes);
            this.groupBox5.Controls.Add(this.horafin_min_viernes);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.horafin_hora_viernes);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.especialidad_viernes);
            this.groupBox5.Location = new System.Drawing.Point(22, 369);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(553, 65);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Viernes";
            // 
            // viernes_activar
            // 
            this.viernes_activar.AutoSize = true;
            this.viernes_activar.Location = new System.Drawing.Point(19, 41);
            this.viernes_activar.Name = "viernes_activar";
            this.viernes_activar.Size = new System.Drawing.Size(15, 14);
            this.viernes_activar.TabIndex = 9;
            this.viernes_activar.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 8;
            this.label17.Text = "Activar";
            // 
            // horainicio_min_viernes
            // 
            this.horainicio_min_viernes.FormattingEnabled = true;
            this.horainicio_min_viernes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_viernes.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_viernes.Name = "horainicio_min_viernes";
            this.horainicio_min_viernes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_viernes.TabIndex = 7;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(68, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Hora Inicio";
            // 
            // horainicio_hora_viernes
            // 
            this.horainicio_hora_viernes.FormattingEnabled = true;
            this.horainicio_hora_viernes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horainicio_hora_viernes.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_viernes.Name = "horainicio_hora_viernes";
            this.horainicio_hora_viernes.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_viernes.TabIndex = 5;
            // 
            // horafin_min_viernes
            // 
            this.horafin_min_viernes.FormattingEnabled = true;
            this.horafin_min_viernes.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_viernes.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_viernes.Name = "horafin_min_viernes";
            this.horafin_min_viernes.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_viernes.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(190, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Hora Fin";
            // 
            // horafin_hora_viernes
            // 
            this.horafin_hora_viernes.FormattingEnabled = true;
            this.horafin_hora_viernes.Items.AddRange(new object[] {
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.horafin_hora_viernes.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_viernes.Name = "horafin_hora_viernes";
            this.horafin_hora_viernes.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_viernes.TabIndex = 2;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(319, 22);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(126, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "Seleccionar Especialidad";
            // 
            // especialidad_viernes
            // 
            this.especialidad_viernes.FormattingEnabled = true;
            this.especialidad_viernes.Location = new System.Drawing.Point(324, 38);
            this.especialidad_viernes.Name = "especialidad_viernes";
            this.especialidad_viernes.Size = new System.Drawing.Size(223, 21);
            this.especialidad_viernes.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.sabado_activar);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.horainicio_min_sabado);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.horainicio_hora_sabado);
            this.groupBox6.Controls.Add(this.horafin_min_sabado);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.horafin_hora_sabado);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.especialidad_sabado);
            this.groupBox6.Location = new System.Drawing.Point(22, 440);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(553, 65);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sábado";
            // 
            // sabado_activar
            // 
            this.sabado_activar.AutoSize = true;
            this.sabado_activar.Location = new System.Drawing.Point(19, 41);
            this.sabado_activar.Name = "sabado_activar";
            this.sabado_activar.Size = new System.Drawing.Size(15, 14);
            this.sabado_activar.TabIndex = 9;
            this.sabado_activar.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Activar";
            // 
            // horainicio_min_sabado
            // 
            this.horainicio_min_sabado.FormattingEnabled = true;
            this.horainicio_min_sabado.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horainicio_min_sabado.Location = new System.Drawing.Point(121, 38);
            this.horainicio_min_sabado.Name = "horainicio_min_sabado";
            this.horainicio_min_sabado.Size = new System.Drawing.Size(42, 21);
            this.horainicio_min_sabado.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(68, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "Hora Inicio";
            // 
            // horainicio_hora_sabado
            // 
            this.horainicio_hora_sabado.FormattingEnabled = true;
            this.horainicio_hora_sabado.Items.AddRange(new object[] {
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.horainicio_hora_sabado.Location = new System.Drawing.Point(73, 38);
            this.horainicio_hora_sabado.Name = "horainicio_hora_sabado";
            this.horainicio_hora_sabado.Size = new System.Drawing.Size(42, 21);
            this.horainicio_hora_sabado.TabIndex = 5;
            // 
            // horafin_min_sabado
            // 
            this.horafin_min_sabado.FormattingEnabled = true;
            this.horafin_min_sabado.Items.AddRange(new object[] {
            "00",
            "30"});
            this.horafin_min_sabado.Location = new System.Drawing.Point(243, 38);
            this.horafin_min_sabado.Name = "horafin_min_sabado";
            this.horafin_min_sabado.Size = new System.Drawing.Size(42, 21);
            this.horafin_min_sabado.TabIndex = 4;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(190, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 13);
            this.label23.TabIndex = 3;
            this.label23.Text = "Hora Fin";
            // 
            // horafin_hora_sabado
            // 
            this.horafin_hora_sabado.FormattingEnabled = true;
            this.horafin_hora_sabado.Items.AddRange(new object[] {
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.horafin_hora_sabado.Location = new System.Drawing.Point(195, 38);
            this.horafin_hora_sabado.Name = "horafin_hora_sabado";
            this.horafin_hora_sabado.Size = new System.Drawing.Size(42, 21);
            this.horafin_hora_sabado.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(319, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(126, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Seleccionar Especialidad";
            // 
            // especialidad_sabado
            // 
            this.especialidad_sabado.FormattingEnabled = true;
            this.especialidad_sabado.Location = new System.Drawing.Point(324, 38);
            this.especialidad_sabado.Name = "especialidad_sabado";
            this.especialidad_sabado.Size = new System.Drawing.Size(223, 21);
            this.especialidad_sabado.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(180, 521);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Generar Agenda";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // fecha_desde
            // 
            this.fecha_desde.CustomFormat = "";
            this.fecha_desde.Location = new System.Drawing.Point(71, 49);
            this.fecha_desde.Name = "fecha_desde";
            this.fecha_desde.Size = new System.Drawing.Size(200, 20);
            this.fecha_desde.TabIndex = 14;
            // 
            // fecha_hasta
            // 
            this.fecha_hasta.CustomFormat = "";
            this.fecha_hasta.Location = new System.Drawing.Point(343, 49);
            this.fecha_hasta.Name = "fecha_hasta";
            this.fecha_hasta.Size = new System.Drawing.Size(200, 20);
            this.fecha_hasta.TabIndex = 15;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(21, 55);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 13);
            this.label25.TabIndex = 16;
            this.label25.Text = "Desde: ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(293, 55);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(38, 13);
            this.label26.TabIndex = 17;
            this.label26.Text = "Hasta:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(21, 24);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(158, 13);
            this.label27.TabIndex = 18;
            this.label27.Text = "Seleccionar rango de la agenda";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(510, 521);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "Volver";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Registrar_agenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 556);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.fecha_hasta);
            this.Controls.Add(this.fecha_desde);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Registrar_agenda";
            this.Text = "Registrar Agenda";
            this.Load += new System.EventHandler(this.Registrar_agenda_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox lunes_activar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox horainicio_min_lunes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox horainicio_hora_lunes;
        private System.Windows.Forms.ComboBox horafin_min_lunes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox horafin_hora_lunes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox especialidad_lunes;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox martes_activar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox horainicio_min_martes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox horainicio_hora_martes;
        private System.Windows.Forms.ComboBox horafin_min_martes;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox horafin_hora_martes;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox especialidad_martes;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox miercoles_activar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox horainicio_min_miercoles;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox horainicio_hora_miercoles;
        private System.Windows.Forms.ComboBox horafin_min_miercoles;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox horafin_hora_miercoles;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox especialidad_miercoles;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox jueves_activar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox horainicio_min_jueves;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox horainicio_hora_jueves;
        private System.Windows.Forms.ComboBox horafin_min_jueves;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox horafin_hora_jueves;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox especialidad_jueves;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox viernes_activar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox horainicio_min_viernes;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox horainicio_hora_viernes;
        private System.Windows.Forms.ComboBox horafin_min_viernes;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox horafin_hora_viernes;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox especialidad_viernes;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox sabado_activar;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox horainicio_min_sabado;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox horainicio_hora_sabado;
        private System.Windows.Forms.ComboBox horafin_min_sabado;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox horafin_hora_sabado;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox especialidad_sabado;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker fecha_desde;
        private System.Windows.Forms.DateTimePicker fecha_hasta;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button2;

    }
}